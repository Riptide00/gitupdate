"""Configuration for automated code snippet testing."""
gists_location = "C:\\Users\\Riptide00\\Desktop\\Projects\\Gists\\Python"
ignore = ['TestGists', 'venv']
python_test = True
coverage_report = False
coverage_run = False
coverage_html = False
coverage_xml = False
